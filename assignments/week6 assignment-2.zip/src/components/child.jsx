import { Component } from "react";
class Child extends Component{
    state = {
        version : 5
    }
    snapshot = [];
    constructor(){
        super();
        console.log("Child Component's constructor was called");
       //  this.state.version = 100;
    }
    static getDerivedStateFromProps(props, state){
       // console.log(arguments[0], arguments[1])
        console.log("Child Component's getDerivedStateFromProps was called");
        return {
            version : props.parent_version+1
        }
    }
    shouldComponentUpdate(currentProp, currentState){
        // console.log(arguments[0], arguments[1], arguments[2])
        console.log("Child Component's shouldComponentUpdate was called");
        if(currentProp.parent_version > 50){
            return false;
        }else{
            return true;
        }
    }
    getSnapshotBeforeUpdate(prevProp, prevState){
        console.log(arguments[0], arguments[1]);
        console.log("Child Component's getSnapshotBeforeUpdate was called");
        this.snapshot.push({oldProp : prevProp, oldState : prevState });
        console.log(this.snapshot.length);
        console.log(JSON.stringify(this.snapshot));
        return true
    }
    componentDidMount(){
        // subscribe ajax  call
        console.log("Child Component's componentDidMount was called")
    }
    componentDidUpdate(){
        console.log("Child Component's componentDidUpdate was called")
    }
    componentWillUnmount(){
        // unsubscribe ajax  call
        console.log("Child Component's componentWillUnmount was called")
    }
    render(){
        console.log("Child Component's render was called")
        return <div style={ { border : "2px solid red", padding : "10px"} }>
                   <h2>Child Component</h2>
                   <h3>Version : { this.state.version }</h3>
                   <h3>Parent Version : { this.props.parent_version }</h3>
               </div>
    }
}
export default Child;