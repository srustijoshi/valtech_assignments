import { useRef } from "react";
import { Component } from "react";
import { useReducer } from "react";
let App = () => {
    let reducerFun = (state,action)=>{
        switch(action.type){
            case "name": return{...state,name:action.payload}
            case "email": return{...state,email:action.payload}
            case "age": return{...state,age:action.payload}
            case "phone": return{...state,phone:action.payload}
            default: return state
        }
    }
    let [store, dispatch]=useReducer(reducerFun,{name : "", email : "", age : 0,phone : ""})
    let userDetailsChangeHandler = () => {
        dispatch({type: "name", payload:sname.current.value})
        dispatch({type: "email", payload:semail.current.value})
        dispatch({type: "age", payload:sage.current.value})
        dispatch({type: "phone", payload:sphone.current.value})
    }
    let sname=useRef();
    let semail=useRef();
    let sage=useRef();
    let sphone=useRef();
    
       return <div className="container">
                   <h1>Forms in React</h1>
                   <div className="mb-3">
                    <label htmlFor="name" className="form-label">User Name</label>
                    <input ref={sname}  className="form-control" id="name" placeholder="User Name"/>
                   </div>
                   <div className="mb-3">
                    <label htmlFor="email" className="form-label">User eMail</label>
                    <input ref={semail}  type="email" className="form-control" id="email" placeholder="User eMail"/>
                   </div>
                   <div className="mb-3">
                    <label htmlFor="age" className="form-label">User Age</label>
                    <input  ref={sage}  type="number" className="form-control" id="age" placeholder="User Age"/>
                   </div>
                   <div className="mb-3">
                    <label htmlFor="phone" className="form-label">User Phone</label>
                    <input  ref={sphone}  className="form-control" id="phone" placeholder="Your Phone"/>
                   </div>
                   <div className="mb-3">
                   <button className="btn btn-primary" onClick={userDetailsChangeHandler}>Register</button>
                   </div>
        <ul>
            <li>User Name : { store.name }</li>
            <li>User eMail : { store.email }</li>
            <li>User Age : { store.age }</li>
            <li>User Phone : { store.phone }</li>
        </ul>
              </div>
    }

export default App;
 
